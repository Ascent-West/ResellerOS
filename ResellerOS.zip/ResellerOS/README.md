# ResellerOS

**ResellerOS** is a simple, beginner-friendly profit tracker for app resellers and anyone who buys and sells items for profit. It is written in Python with Streamlit, and the whole project lives in a single file, `app.py`, so it's easy to read, run, and customize.

## Features

- **Quick item entry:** record name, category, buy price, sell price, date, and sold status.
- **Inventory management:** every item appears in a table with a delete button.
- **Dashboard:** total profit, average margin %, and best category at a glance.
- **Visual insights:** a bar chart of profit by category.
- **Persistent storage:** data is saved in a local SQLite database.

## How it works

Profit and margin are calculated only for items marked as sold. Margin is profit divided by sell price.

## Run it

```
pip install -r requirements.txt
streamlit run app.py
```

Your browser opens at http://localhost:8501.
