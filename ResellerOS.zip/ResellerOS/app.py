import sqlite3
from datetime import date

import pandas as pd
import streamlit as st

# ---------- SECTION 1: Database setup ----------
DB_FILE = "reselleros.db"


def init_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            buy_price REAL NOT NULL,
            sell_price REAL NOT NULL,
            date TEXT NOT NULL,
            sold INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def add_item(name, category, buy_price, sell_price, item_date, sold):
    conn = sqlite3.connect(DB_FILE)
    conn.execute(
        "INSERT INTO items (name, category, buy_price, sell_price, date, sold) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (name, category, buy_price, sell_price, str(item_date), int(sold)),
    )
    conn.commit()
    conn.close()


def delete_item(item_id):
    conn = sqlite3.connect(DB_FILE)
    conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()


def load_items():
    conn = sqlite3.connect(DB_FILE)
    df = pd.read_sql_query("SELECT * FROM items ORDER BY date DESC, id DESC", conn)
    conn.close()
    return df


# ---------- SECTION 2: Page setup ----------
st.set_page_config(page_title="ResellerOS", page_icon="📦", layout="wide")
init_db()

st.title("📦 ResellerOS")
st.caption("A simple profit tracker for resellers.")

# ---------- SECTION 3: Add-item form ----------
st.header("Add an item")

with st.form("add_form", clear_on_submit=True):
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Item name")
        category = st.text_input("Category (e.g. Sneakers, Phones)")
        item_date = st.date_input("Date", value=date.today())
    with col2:
        buy_price = st.number_input("Buy price", min_value=0.0, step=1.0, format="%.2f")
        sell_price = st.number_input("Sell price", min_value=0.0, step=1.0, format="%.2f")
        sold = st.checkbox("Sold?")
    submitted = st.form_submit_button("Add item")

if submitted:
    if not name.strip() or not category.strip():
        st.error("Please fill in both the item name and the category.")
    elif sold and sell_price <= 0:
        st.error("You marked this item as sold, so please enter a sell price.")
    else:
        add_item(name.strip(), category.strip().title(), buy_price, sell_price, item_date, sold)
        st.success(f"Added '{name.strip()}'!")
        st.rerun()

# ---------- SECTION 4: Load data and calculate numbers ----------
df = load_items()

# Profit and margin only make sense for items that are sold.
if not df.empty:
    df["profit"] = (df["sell_price"] - df["buy_price"]).where(df["sold"] == 1, 0.0)
    df["margin"] = ((df["profit"] / df["sell_price"]) * 100).where(
        (df["sold"] == 1) & (df["sell_price"] > 0)
    )

# ---------- SECTION 5: Dashboard ----------
st.header("Dashboard")

sold_df = df[df["sold"] == 1] if not df.empty else df

if sold_df.empty:
    st.info("No sold items yet. Add an item and tick 'Sold?' to see your stats.")
else:
    total_profit = sold_df["profit"].sum()
    avg_margin = sold_df["margin"].mean()
    profit_by_category = sold_df.groupby("category")["profit"].sum()
    best_category = profit_by_category.idxmax()

    m1, m2, m3 = st.columns(3)
    m1.metric("Total profit", f"{total_profit:,.2f}")
    m2.metric("Average margin", f"{avg_margin:.1f}%")
    m3.metric("Best category", best_category)

    st.subheader("Profit by category")
    st.bar_chart(profit_by_category)

# ---------- SECTION 6: Items table with delete buttons ----------
st.header("All items")

if df.empty:
    st.write("Nothing here yet.")
else:
    header = st.columns([3, 2, 2, 2, 2, 1, 1])
    for col, label in zip(header, ["Name", "Category", "Buy", "Sell", "Date", "Sold", ""]):
        col.markdown(f"**{label}**")

    for _, row in df.iterrows():
        cols = st.columns([3, 2, 2, 2, 2, 1, 1])
        cols[0].write(row["name"])
        cols[1].write(row["category"])
        cols[2].write(f"{row['buy_price']:,.2f}")
        cols[3].write(f"{row['sell_price']:,.2f}")
        cols[4].write(row["date"])
        cols[5].write("✅" if row["sold"] == 1 else "❌")
        if cols[6].button("🗑️", key=f"delete_{row['id']}"):
            delete_item(int(row["id"]))
            st.rerun()
